# Socket.IO Events Documentation

## 🔌 Connection Events

### Client → Server
- **Connection**: `socket.connect()` with auth token
  ```javascript
  // Client connection
  const socket = io('http://localhost:5000', {
    auth: {
      token: 'your-jwt-token'
    }
  });
  ```

### Server → Client
- **userOnline**: إشعار عند اتصال مستخدم
  ```javascript
  // Server emits
  io.emit("userOnline", { userId: "user_id" });
  ```
- **userOffline**: إشعار عند انفصال مستخدم
  ```javascript
  // Server emits
  io.emit("userOffline", { userId: "user_id" });
  ```

## 💬 Message Events

### Client → Server
- **sendMessage**: إرسال رسالة جديدة (مع حفظ في قاعدة البيانات)
  ```javascript
  // Client sends
  socket.emit("sendMessage", {
    receiverId: "receiver_user_id",
    text: "Hello world", // optional
    imageUrl: "https://example.com/image.jpg" // optional
  });
  ```

- **requestOnlineUsers**: طلب قائمة المستخدمين المتصلين
  ```javascript
  // Client requests
  socket.emit("requestOnlineUsers");
  ```

### Server → Client
- **newMessage**: استقبال رسالة جديدة
  ```javascript
  // Server emits to specific user
  io.to(receiverSocketId).emit("newMessage", {
    senderId: "sender_user_id",
    text: "Hello world", // or null
    imageUrl: "https://example.com/image.jpg", // or null
    timestamp: 1640995200000,
    messageId: "message_id_from_database"
  });
  ```

- **messageSent**: تأكيد إرسال الرسالة
  ```javascript
  // Server confirms message sent
  socket.emit("messageSent", {
    messageId: "message_id_from_database",
    timestamp: 1640995200000
  });
  ```

- **messageError**: خطأ في إرسال الرسالة
  ```javascript
  // Server sends error
  socket.emit("messageError", {
    error: "Failed to send message"
  });
  ```

- **onlineUsers**: قائمة المستخدمين المتصلين
  ```javascript
  // Server sends online users
  socket.emit("onlineUsers", {
    users: ["user1_id", "user2_id", "user3_id"]
  });
  ```

## 🔐 Authentication

### JWT Token Verification
```javascript
// Server middleware
io.use(async (socket, next) => {
  try {
    const token = socket.handshake.auth.token;
    if (!token) return next(new Error("No token"));

    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    socket.user = decoded;
    next();
  } catch (err) {
    return next(new Error("Unauthorized socket"));
  }
});
```

## 📊 Connection Management

### Connected Users Tracking
```javascript
// Server maintains a Map of connected users
const connectedUsers = new Map();
// Key: userId, Value: socketId

// On connection
connectedUsers.set(userId, socket.id);

// On disconnect
connectedUsers.delete(userId);
```

## 🚀 Usage Examples

### Frontend Connection
```javascript
import { io } from 'socket.io-client';

const socket = io('http://localhost:5000', {
  auth: {
    token: localStorage.getItem('token')
  }
});

// Listen for new messages
socket.on('newMessage', (message) => {
  console.log('New message received:', message);
  // Update UI with new message
});

// Listen for user status changes
socket.on('userOnline', ({ userId }) => {
  console.log('User online:', userId);
  // Update user status in UI
});

socket.on('userOffline', ({ userId }) => {
  console.log('User offline:', userId);
  // Update user status in UI
});

// Send a message
socket.emit('sendMessage', {
  receiverId: 'user123',
  text: 'Hello!'
});
```

## ⚠️ Important Notes

1. **Authentication Required**: All socket connections require a valid JWT token
2. **Real-time Updates**: Messages sent via API are also sent via sockets if receiver is online
3. **Connection Tracking**: Server tracks all connected users for real-time messaging
4. **Error Handling**: Unauthorized connections are automatically disconnected
5. **CORS Configuration**: Socket.IO is configured to accept connections from any origin

## 🔧 Environment Variables

Make sure these are set in your `.env` file:
```
JWT_SECRET=your_jwt_secret_here
PORT=5000
```
