import jwt from "jsonwebtoken";
import { setOnlineStatus } from "../controllers/userController.js";

const connectedUsers = new Map();

export default function initSocket(io) {
  // التحقق من JWT قبل الاتصال
  io.use(async (socket, next) => {
    try {
      const token = socket.handshake.auth.token;
      if (!token) return next(new Error("No token"));

      const decoded = jwt.verify(token, process.env.JWT_SECRET);
      socket.user = decoded;

      next();
    } catch (err) {
      return next(new Error("Unauthorized socket"));
    }
  });

  io.on("connection", async (socket) => {
    const userId = socket.user?.id;
    if (!userId) return socket.disconnect(true);

    connectedUsers.set(userId, socket.id);
    await setOnlineStatus(userId, true);
    io.emit("userOnline", { userId });

    console.log(`✅ User ${userId} connected via socket: ${socket.id}`);

    // إرسال رسالة (نص أو صورة أو الاثنين)
    socket.on("sendMessage", ({ receiverId, text, imageUrl }) => {
      if (!receiverId || (!text && !imageUrl)) return;

      // إرسال للمستلم
      const receiverSocket = connectedUsers.get(receiverId);
      if (receiverSocket) {
        io.to(receiverSocket).emit("newMessage", {
          messageId: `temp-${Date.now()}`,
          senderId: userId,
          text: text || null,
          imageUrl: imageUrl || null,
          timestamp: Date.now(),
        });
      }
      
      // إرسال للمرسل أيضاً (ليرى رسالته فوراً)
      const senderSocket = connectedUsers.get(userId);
      if (senderSocket) {
        io.to(senderSocket).emit("newMessage", {
          messageId: `temp-${Date.now()}`,
          senderId: userId,
          text: text || null,
          imageUrl: imageUrl || null,
          timestamp: Date.now(),
        });
      }
    });

    socket.on("disconnect", async () => {
      connectedUsers.delete(userId);
      await setOnlineStatus(userId, false);
      io.emit("userOffline", { userId });
      console.log(`❌ User ${userId} disconnected`);
    });
  });

  global.connectedUsers = connectedUsers;
}
