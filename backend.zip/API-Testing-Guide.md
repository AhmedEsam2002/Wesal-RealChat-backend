# 🧪 API Testing Guide

This guide will help you test the Chat Application API using Postman.

## 📋 Prerequisites

1. **Postman** installed on your machine
2. **Server running** on `http://localhost:5000`
3. **MongoDB** database connected
4. **Environment variables** configured

## 🚀 Getting Started

### 1. Import Postman Collection

1. Open Postman
2. Click **Import** button
3. Select the file: `Chat-App-API-Collection.postman_collection.json`
4. The collection will be imported with all endpoints organized

### 2. Set Up Environment Variables

In Postman, create a new environment with these variables:

| Variable | Initial Value | Current Value | Description |
|----------|---------------|---------------|-------------|
| `baseUrl` | `http://localhost:5000` | `http://localhost:5000` | API base URL |
| `authToken` | `` | `` | JWT token (auto-filled after login) |
| `userId` | `` | `` | User ID (auto-filled after user creation) |
| `receiverId` | `` | `` | Receiver ID for messaging |
| `resetToken` | `` | `` | Password reset token |

### 3. Testing Flow

Follow this sequence to test all features:

## 🔐 Step 1: Authentication Testing

### 1.1 Sign Up
1. Go to **Authentication** folder
2. Select **Sign Up** request
3. Update the request body with your test data:
   ```json
   {
     "name": "Test User",
     "email": "test@example.com",
     "password": "password123",
     "confirmPassword": "password123"
   }
   ```
4. Send the request
5. **Save the token** from the response for next requests

### 1.2 Login
1. Select **Login** request
2. Update the request body:
   ```json
   {
     "email": "test@example.com",
     "password": "password123"
   }
   ```
3. Send the request
4. **Copy the token** from the response

### 1.3 Set Authentication Token
1. In your Postman environment
2. Set `authToken` variable to the token from login response
3. This will automatically be used in all authenticated requests

## 👥 Step 2: User Management Testing

### 2.1 Get All Users
1. Go to **Users** folder
2. Select **Get All Users** request
3. Send the request
4. **Save a user ID** from the response for messaging tests

### 2.2 Update My Profile
1. Select **Update My Profile** request
2. Update the request body:
   ```json
   {
     "name": "Updated Test User",
     "email": "updated@example.com",
     "avatar": "https://example.com/avatar.jpg"
   }
   ```
3. Send the request

### 2.3 Get User by ID
1. Select **Get User by ID** request
2. Replace `{{userId}}` with an actual user ID
3. Send the request

## 💬 Step 3: Messaging Testing

### 3.1 Set Receiver ID
1. From the **Get All Users** response, copy a user ID
2. Set the `receiverId` environment variable to this ID

### 3.2 Send Message
1. Go to **Messages** folder
2. Select **Send Message** request
3. Update the request body:
   ```json
   {
     "text": "Hello! This is a test message.",
     "img": "https://example.com/test-image.jpg"
   }
   ```
4. Send the request

### 3.3 Get Messages
1. Select **Get Messages with User** request
2. Send the request
3. Verify the message history is returned

## 💭 Step 4: Conversations Testing

### 4.1 Get My Conversations
1. Go to **Conversations** folder
2. Select **Get My Conversations** request
3. Send the request
4. Verify your conversations are listed

### 4.2 Get Conversation with User
1. Select **Get Conversation with User** request
2. Replace `{{userId}}` with the receiver ID
3. Send the request
4. Verify the conversation details

## 🔌 Step 5: Socket.IO Testing

### 5.1 Test Real-time Messaging
1. Open a web browser
2. Go to `http://localhost:5000`
3. Open browser console
4. Connect to Socket.IO:
   ```javascript
   const socket = io('http://localhost:5000', {
     auth: {
       token: 'your-jwt-token-here'
     }
   });
   ```

### 5.2 Send Message via Socket
```javascript
socket.emit("sendMessage", {
  receiverId: "receiver_user_id",
  text: "Hello from Socket.IO!",
  imageUrl: "https://example.com/image.jpg"
});
```

### 5.3 Listen for Messages
```javascript
socket.on("newMessage", (message) => {
  console.log("New message received:", message);
});
```

## 🧪 Advanced Testing

### Testing Error Cases

#### 1. Invalid Authentication
1. Remove the `Authorization` header
2. Send any authenticated request
3. Verify you get a 401 error

#### 2. Invalid Input
1. Send signup request with missing fields
2. Verify you get a 400 error with validation message

#### 3. Duplicate Email
1. Try to sign up with an existing email
2. Verify you get an appropriate error

### Testing Rate Limiting
1. Send multiple requests rapidly
2. Verify you get rate limit error after 100 requests per 15 minutes

### Testing File Upload
1. Use the **Update My Profile** endpoint
2. Include an `avatar` field with image URL
3. Verify the image is uploaded to Cloudinary

## 📊 Response Validation

### Success Response Format
```json
{
  "status": "success",
  "data": {
    // Response data
  }
}
```

### Error Response Format
```json
{
  "status": "error",
  "message": "Error description",
  "statusCode": 400
}
```

### Authentication Response
```json
{
  "status": "success",
  "token": "jwt_token_here",
  "data": {
    "user": {
      "_id": "user_id",
      "name": "User Name",
      "email": "user@example.com",
      "avatar": "",
      "role": "user",
      "online": false
    }
  }
}
```

## 🔧 Troubleshooting

### Common Issues

#### 1. Connection Refused
- **Problem**: Cannot connect to server
- **Solution**: Ensure server is running on port 5000

#### 2. Authentication Failed
- **Problem**: 401 Unauthorized errors
- **Solution**: Check if token is valid and properly set in environment

#### 3. Database Connection Error
- **Problem**: 500 Internal Server Error
- **Solution**: Verify MongoDB is running and connection string is correct

#### 4. Missing Environment Variables
- **Problem**: Server won't start
- **Solution**: Check `.env` file has all required variables

### Debug Tips

1. **Check Server Logs**: Monitor console output for errors
2. **Verify Environment**: Ensure all variables are set correctly
3. **Test Database**: Confirm MongoDB connection is working
4. **Check Network**: Ensure no firewall blocking port 5000

## 📝 Test Data Examples

### User Registration
```json
{
  "name": "John Doe",
  "email": "john@example.com",
  "password": "password123",
  "confirmPassword": "password123"
}
```

### User Login
```json
{
  "email": "john@example.com",
  "password": "password123"
}
```

### Send Message
```json
{
  "text": "Hello! How are you?",
  "img": "https://example.com/image.jpg"
}
```

### Update Profile
```json
{
  "name": "Updated Name",
  "email": "updated@example.com",
  "avatar": "https://example.com/avatar.jpg"
}
```

## 🎯 Testing Checklist

- [ ] Server starts without errors
- [ ] Database connection successful
- [ ] User registration works
- [ ] User login works
- [ ] JWT token is generated
- [ ] Authentication middleware works
- [ ] Get all users works
- [ ] Update profile works
- [ ] Send message works
- [ ] Get messages works
- [ ] Get conversations works
- [ ] Socket.IO connection works
- [ ] Real-time messaging works
- [ ] Error handling works
- [ ] Rate limiting works
- [ ] File upload works

## 🚀 Next Steps

After successful testing:

1. **Frontend Integration**: Use the API endpoints in your frontend application
2. **Socket.IO Integration**: Implement real-time features
3. **Production Deployment**: Deploy to production environment
4. **Monitoring**: Set up logging and monitoring
5. **Security**: Review and enhance security measures

---

**Happy Testing! 🎉** 