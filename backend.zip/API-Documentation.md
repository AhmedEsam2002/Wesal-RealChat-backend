# Chat Application API Documentation

## 📋 Table of Contents
- [Overview](#overview)
- [Base URL](#base-url)
- [Authentication](#authentication)
- [Error Handling](#error-handling)
- [API Endpoints](#api-endpoints)
  - [Authentication](#authentication-endpoints)
  - [Users](#users-endpoints)
  - [Messages](#messages-endpoints)
  - [Conversations](#conversations-endpoints)
- [Socket.IO Events](#socketio-events)
- [Models](#models)

## 🌐 Overview

This is a real-time chat application API built with Node.js, Express, MongoDB, and Socket.IO. The API provides authentication, user management, messaging, and conversation features with real-time capabilities.

## 🔗 Base URL

```
Development: http://localhost:5000
Production: https://your-domain.com
```

## 🔐 Authentication

The API uses JWT (JSON Web Tokens) for authentication. Include the token in the Authorization header:

```
Authorization: Bearer <your-jwt-token>
```

## ⚠️ Error Handling

All errors follow this format:

```json
{
  "status": "error",
  "message": "Error description",
  "statusCode": 400
}
```

## 📡 API Endpoints

### 🔐 Authentication Endpoints

#### 1. Sign Up
**POST** `/api/auth/signup`

Create a new user account.

**Request Body:**
```json
{
  "name": "John Doe",
  "email": "john@example.com",
  "password": "password123",
  "confirmPassword": "password123"
}
```

**Response (201):**
```json
{
  "status": "success",
  "token": "jwt_token_here",
  "data": {
    "user": {
      "_id": "user_id",
      "name": "John Doe",
      "email": "john@example.com",
      "avatar": "",
      "role": "user",
      "online": false
    }
  }
}
```

#### 2. Login
**POST** `/api/auth/login`

Authenticate user and get access token.

**Request Body:**
```json
{
  "email": "john@example.com",
  "password": "password123"
}
```

**Response (200):**
```json
{
  "status": "success",
  "token": "jwt_token_here",
  "data": {
    "user": {
      "_id": "user_id",
      "name": "John Doe",
      "email": "john@example.com",
      "avatar": "",
      "role": "user",
      "online": false
    }
  }
}
```

#### 3. Forget Password
**POST** `/api/auth/forget-password`

Send password reset email.

**Request Body:**
```json
{
  "email": "john@example.com"
}
```

**Response (200):**
```json
{
  "status": "success",
  "message": "Token sent to email!"
}
```

#### 4. Reset Password
**PATCH** `/api/auth/reset-password/:token`

Reset password using token from email.

**Request Body:**
```json
{
  "newPassword": "newpassword123",
  "confirmNewPassword": "newpassword123"
}
```

**Response (200):**
```json
{
  "status": "success",
  "token": "new_jwt_token",
  "data": {
    "user": {
      "_id": "user_id",
      "name": "John Doe",
      "email": "john@example.com"
    }
  }
}
```

#### 5. Update Password
**PATCH** `/api/auth/update-password`

Update password (requires authentication).

**Headers:**
```
Authorization: Bearer <jwt_token>
```

**Request Body:**
```json
{
  "currentPassword": "password123",
  "newPassword": "newpassword123",
  "confirmNewPassword": "newpassword123"
}
```

**Response (200):**
```json
{
  "status": "success",
  "token": "new_jwt_token",
  "data": {
    "user": {
      "_id": "user_id",
      "name": "John Doe",
      "email": "john@example.com"
    }
  }
}
```

### 👥 Users Endpoints

#### 1. Get All Users
**GET** `/api/user`

Get paginated list of all users (requires authentication).

**Headers:**
```
Authorization: Bearer <jwt_token>
```

**Query Parameters:**
- `page` (optional): Page number (default: 1)
- `limit` (optional): Items per page (default: 10)
- `sort` (optional): Sort field
- `fields` (optional): Fields to include

**Response (200):**
```json
{
  "status": "success",
  "results": 2,
  "data": {
    "users": [
      {
        "_id": "user_id_1",
        "name": "John Doe",
        "email": "john@example.com",
        "avatar": "",
        "role": "user",
        "online": false
      },
      {
        "_id": "user_id_2",
        "name": "Jane Smith",
        "email": "jane@example.com",
        "avatar": "",
        "role": "user",
        "online": true
      }
    ]
  }
}
```

#### 2. Get User by ID
**GET** `/api/user/:id`

Get specific user by ID.

**Response (200):**
```json
{
  "status": "success",
  "data": {
    "user": {
      "_id": "user_id",
      "name": "John Doe",
      "email": "john@example.com",
      "avatar": "",
      "role": "user",
      "online": false
    }
  }
}
```

#### 3. Update My Profile
**POST** `/api/user/me`

Update current user's profile (requires authentication).

**Headers:**
```
Authorization: Bearer <jwt_token>
```

**Request Body:**
```json
{
  "name": "Updated Name",
  "email": "updated@example.com",
  "avatar": "https://example.com/avatar.jpg"
}
```

**Response (200):**
```json
{
  "status": "success",
  "data": {
    "user": {
      "_id": "user_id",
      "name": "Updated Name",
      "email": "updated@example.com",
      "avatar": "https://example.com/avatar.jpg",
      "role": "user",
      "online": false
    }
  }
}
```

#### 4. Delete My Account
**DELETE** `/api/user/me`

Delete current user's account (requires authentication).

**Headers:**
```
Authorization: Bearer <jwt_token>
```

**Response (204):**
```json
{
  "status": "success",
  "data": null
}
```

#### 5. Create User (Admin Only)
**POST** `/api/user`

Create new user (requires admin authentication).

**Headers:**
```
Authorization: Bearer <jwt_token>
```

**Request Body:**
```json
{
  "name": "New User",
  "email": "newuser@example.com",
  "password": "password123",
  "confirmPassword": "password123",
  "role": "user"
}
```

**Response (201):**
```json
{
  "status": "success",
  "data": {
    "user": {
      "_id": "new_user_id",
      "name": "New User",
      "email": "newuser@example.com",
      "role": "user"
    }
  }
}
```

#### 6. Update User (Admin Only)
**PATCH** `/api/user/:id`

Update user by ID (requires admin authentication).

**Headers:**
```
Authorization: Bearer <jwt_token>
```

**Request Body:**
```json
{
  "name": "Updated User Name",
  "email": "updateduser@example.com",
  "role": "admin"
}
```

**Response (200):**
```json
{
  "status": "success",
  "data": {
    "user": {
      "_id": "user_id",
      "name": "Updated User Name",
      "email": "updateduser@example.com",
      "role": "admin"
    }
  }
}
```

#### 7. Delete User (Admin Only)
**DELETE** `/api/user/:id`

Delete user by ID (requires admin authentication).

**Headers:**
```
Authorization: Bearer <jwt_token>
```

**Response (204):**
```json
{
  "status": "success",
  "data": null
}
```

### 💬 Messages Endpoints

#### 1. Send Message
**POST** `/api/messages/:receiverId`

Send a message to a specific user (requires authentication).

**Headers:**
```
Authorization: Bearer <jwt_token>
```

**Request Body:**
```json
{
  "text": "Hello! How are you?",
  "img": "https://example.com/image.jpg"
}
```

**Response (201):**
```json
{
  "status": "success",
  "data": {
    "message": {
      "_id": "message_id",
      "sender": "sender_user_id",
      "receiver": "receiver_user_id",
      "text": "Hello! How are you?",
      "img": "https://example.com/image.jpg",
      "createdAt": "2024-01-01T00:00:00.000Z",
      "updatedAt": "2024-01-01T00:00:00.000Z"
    }
  }
}
```

#### 2. Get Messages with User
**GET** `/api/messages/:receiverId`

Get all messages between current user and specific user (requires authentication).

**Headers:**
```
Authorization: Bearer <jwt_token>
```

**Response (200):**
```json
{
  "status": "success",
  "data": {
    "messages": [
      {
        "_id": "message_id_1",
        "sender": {
          "_id": "sender_id",
          "name": "John Doe",
          "avatar": "",
          "email": "john@example.com",
          "online": false
        },
        "receiver": {
          "_id": "receiver_id",
          "name": "Jane Smith",
          "avatar": "",
          "email": "jane@example.com",
          "online": true
        },
        "text": "Hello!",
        "img": "",
        "createdAt": "2024-01-01T00:00:00.000Z",
        "updatedAt": "2024-01-01T00:00:00.000Z"
      }
    ]
  }
}
```

### 💭 Conversations Endpoints

#### 1. Get My Conversations
**GET** `/api/conversations`

Get all conversations for current user (requires authentication).

**Headers:**
```
Authorization: Bearer <jwt_token>
```

**Response (200):**
```json
{
  "status": "success",
  "results": 2,
  "data": {
    "conversations": [
      {
        "_id": "conversation_id_1",
        "participants": [
          {
            "_id": "user_id_1",
            "name": "John Doe",
            "avatar": ""
          },
          {
            "_id": "user_id_2",
            "name": "Jane Smith",
            "avatar": ""
          }
        ],
        "lastMessage": {
          "_id": "message_id",
          "text": "Hello!",
          "createdAt": "2024-01-01T00:00:00.000Z"
        },
        "createdAt": "2024-01-01T00:00:00.000Z",
        "updatedAt": "2024-01-01T00:00:00.000Z"
      }
    ]
  }
}
```

#### 2. Get Conversation with User
**GET** `/api/conversations/:userId`

Get specific conversation with a user (requires authentication).

**Headers:**
```
Authorization: Bearer <jwt_token>
```

**Response (200):**
```json
{
  "status": "success",
  "data": {
    "conversation": {
      "_id": "conversation_id",
      "participants": [
        {
          "_id": "user_id_1",
          "name": "John Doe",
          "avatar": ""
        },
        {
          "_id": "user_id_2",
          "name": "Jane Smith",
          "avatar": ""
        }
      ],
      "lastMessage": {
        "_id": "message_id",
        "text": "Hello!",
        "createdAt": "2024-01-01T00:00:00.000Z"
      },
      "createdAt": "2024-01-01T00:00:00.000Z",
      "updatedAt": "2024-01-01T00:00:00.000Z"
    }
  }
}
```

## 🔌 Socket.IO Events

### Connection
```javascript
const socket = io('http://localhost:5000', {
  auth: {
    token: 'your-jwt-token'
  }
});
```

### Events

#### Client → Server
- `sendMessage`: Send a message
  ```javascript
  socket.emit("sendMessage", {
    receiverId: "receiver_user_id",
    text: "Hello world",
    imageUrl: "https://example.com/image.jpg"
  });
  ```

#### Server → Client
- `newMessage`: Receive new message
  ```javascript
  socket.on("newMessage", (message) => {
    console.log("New message:", message);
  });
  ```

- `userOnline`: User connected
  ```javascript
  socket.on("userOnline", ({ userId }) => {
    console.log("User online:", userId);
  });
  ```

- `userOffline`: User disconnected
  ```javascript
  socket.on("userOffline", ({ userId }) => {
    console.log("User offline:", userId);
  });
  ```

## 📊 Models

### User Model
```javascript
{
  _id: ObjectId,
  name: String,
  email: String,
  password: String,
  avatar: String,
  role: String, // "user" | "admin"
  online: Boolean,
  active: Boolean,
  passwordChangedAt: Date,
  passwordResetToken: String,
  passwordResetExpires: Date,
  createdAt: Date,
  updatedAt: Date
}
```

### Message Model
```javascript
{
  _id: ObjectId,
  sender: ObjectId, // ref: User
  receiver: ObjectId, // ref: User
  text: String,
  img: String,
  createdAt: Date,
  updatedAt: Date
}
```

### Conversation Model
```javascript
{
  _id: ObjectId,
  participants: [ObjectId], // ref: User
  lastMessage: ObjectId, // ref: Message
  createdAt: Date,
  updatedAt: Date
}
```

## 🚀 Getting Started

1. **Install Dependencies:**
   ```bash
   npm install
   ```

2. **Environment Variables:**
   Create `.env` file:
   ```
   PORT=5000
   MONGODB_URI=your_mongodb_connection_string
   JWT_SECRET=your_jwt_secret
   JWT_EXPIRES_IN=90d
   EMAIL_FROM=noreply@yourapp.com
   EMAIL_PASSWORD=your_email_password
   CLOUDINARY_CLOUD_NAME=your_cloudinary_name
   CLOUDINARY_API_KEY=your_cloudinary_key
   CLOUDINARY_API_SECRET=your_cloudinary_secret
   ```

3. **Run Development Server:**
   ```bash
   npm run dev
   ```

4. **Test API:**
   Import the Postman collection and start testing!

## 📝 Notes

- All timestamps are in ISO 8601 format
- Passwords are automatically hashed using bcrypt
- JWT tokens expire in 90 days by default
- File uploads are handled via Cloudinary
- Real-time messaging is powered by Socket.IO
- Rate limiting is applied to all API routes 