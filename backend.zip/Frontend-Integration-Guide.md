# Backend-Frontend Integration Guide

This guide explains how the Node.js/Express backend integrates with the React TypeScript frontend.

## API Endpoints Overview

### Authentication Routes (`/api/auth`)

| Method | Endpoint | Description | Request Body | Response |
|--------|----------|-------------|--------------|----------|
| POST | `/signup` | User registration | `{ name, email, password, confirmPassword }` | `{ status, token, data: { user } }` |
| POST | `/login` | User login | `{ email, password }` | `{ status, token, data: { user } }` |
| POST | `/forget-password` | Password reset request | `{ email }` | `{ status, message }` |
| PATCH | `/reset-password/:token` | Password reset | `{ newPassword, confirmNewPassword }` | `{ status, token, data: { user } }` |
| PATCH | `/update-password` | Update password (auth) | `{ currentPassword, newPassword, confirmNewPassword }` | `{ status, token, data: { user } }` |

### User Routes (`/api/user`)

| Method | Endpoint | Description | Auth Required | Response |
|--------|----------|-------------|---------------|----------|
| GET | `/` | Get all users | Yes | `{ status, data: { users } }` |
| POST | `/me` | Update current user | Yes | `{ status, data: { user } }` |
| DELETE | `/me` | Delete current user | Yes | `{ status, data: null }` |
| GET | `/:id` | Get user by ID | No | `{ status, data: { user } }` |
| PATCH | `/:id` | Update user (admin) | Yes | `{ status, data: { user } }` |
| DELETE | `/:id` | Delete user (admin) | Yes | `{ status, data: null }` |

### Message Routes (`/api`)

| Method | Endpoint | Description | Auth Required | Request Body | Response |
|--------|----------|-------------|---------------|--------------|----------|
| POST | `/messages/:receiverId` | Send message | Yes | `{ text?, img? }` | `{ status, data: { message } }` |
| GET | `/messages/:receiverId` | Get messages | Yes | - | `{ status, data: { messages } }` |

### Conversation Routes (`/api/conversations`)

| Method | Endpoint | Description | Auth Required | Response |
|--------|----------|-------------|---------------|----------|
| GET | `/` | Get user's conversations | Yes | `{ status, data: { conversations } }` |
| GET | `/:userId` | Get conversation with user | Yes | `{ status, data: { conversation } }` |

## Data Models

### User Model
```typescript
interface User {
  _id: string;
  name: string;
  email: string;
  role: 'user' | 'admin';
  avatar: string;
  online: boolean;
  createdAt?: string;
  updatedAt?: string;
}
```

### Message Model
```typescript
interface Message {
  _id: string;
  sender: User;
  receiver: User;
  text: string;
  img?: string;
  createdAt: string;
  updatedAt: string;
}
```

### Conversation Model
```typescript
interface Conversation {
  _id: string;
  participants: User[];
  lastMessage?: Message;
  createdAt: string;
  updatedAt: string;
}
```

## Authentication Flow

### 1. User Registration
```typescript
// Frontend request
const response = await apiClient.signup({
  name: "John Doe",
  email: "john@example.com",
  password: "password123",
  confirmPassword: "password123"
});

// Backend response
{
  status: "success",
  token: "jwt_token_here",
  data: {
    user: {
      _id: "user_id",
      name: "John Doe",
      email: "john@example.com",
      role: "user",
      avatar: "",
      online: false
    }
  }
}
```

### 2. User Login
```typescript
// Frontend request
const response = await apiClient.login({
  email: "john@example.com",
  password: "password123"
});

// Backend response (same format as signup)
```

### 3. Protected Routes
All protected routes require the JWT token in the Authorization header:
```
Authorization: Bearer <jwt_token>
```

## Error Handling

### Standard Error Response
```typescript
{
  status: "error" | "fail",
  message: "Error description",
  // Optional additional fields
}
```

### Common Error Status Codes
- `400` - Bad Request (validation errors)
- `401` - Unauthorized (invalid/missing token)
- `403` - Forbidden (insufficient permissions)
- `404` - Not Found
- `500` - Internal Server Error

## File Upload (Images)

### Image Upload Flow
1. Frontend converts image to base64
2. Sends base64 string in message request
3. Backend uploads to Cloudinary
4. Returns Cloudinary URL in response

### Example
```typescript
// Frontend sends
{
  text: "Check out this image!",
  img: "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQ..."
}

// Backend responds
{
  status: "success",
  data: {
    message: {
      _id: "message_id",
      text: "Check out this image!",
      img: "https://res.cloudinary.com/.../image.jpg",
      sender: { ... },
      receiver: { ... }
    }
  }
}
```

## Real-time Features

### WebSocket Events
The backend supports WebSocket connections for real-time features:

#### Connection Events
- `connect` - User connects
- `disconnect` - User disconnects

#### Message Events
- `newMessage` - New message received
- `typing` - User typing indicator
- `stopTyping` - User stopped typing

### WebSocket Data Format
```typescript
// New message event
{
  senderId: "user_id",
  text: "Hello!",
  imageUrl?: "https://...",
  timestamp: 1234567890
}
```

## CORS Configuration

The backend is configured to accept requests from the frontend:

```javascript
app.use(cors({
  origin: "*", // In production, specify exact frontend URL
  credentials: true,
  methods: ["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"],
  allowedHeaders: ["Content-Type", "Authorization"],
}));
```

## Rate Limiting

The backend implements rate limiting:
- 100 requests per 15 minutes per IP
- Applied to `/api` routes
- Returns 429 status code when exceeded

## Security Features

### JWT Token Security
- Tokens expire in 90 days (configurable)
- Stored in HTTP-only cookies
- Also available in Authorization header

### Password Security
- Passwords hashed with bcrypt
- Minimum 8 characters required
- Password change tracking for token invalidation

### Input Validation
- Email format validation
- Password strength requirements
- File type and size validation for images

## Environment Variables

### Required Backend Environment Variables
```env
# Database
MONGODB_URI=mongodb://localhost:27017/chat-app

# JWT
JWT_SECRET=your_jwt_secret_here
JWT_EXPIRES_IN=90d
JWT_COOKIE_EXPIRES_IN=90

# Cloudinary (for image uploads)
CLOUDINARY_CLOUD_NAME=your_cloud_name
CLOUDINARY_API_KEY=your_api_key
CLOUDINARY_API_SECRET=your_api_secret

# Email (optional)
EMAIL_FROM=noreply@yourapp.com
EMAIL_PASSWORD=your_email_password
```

## Testing the Integration

### 1. Start Backend
```bash
cd backend
npm install
npm start
```

### 2. Start Frontend
```bash
cd frontend
npm install
npm run dev
```

### 3. Test Authentication
1. Open frontend at `http://localhost:5173`
2. Create a new account
3. Verify login/logout functionality

### 4. Test Chat Features
1. Create multiple user accounts
2. Send messages between users
3. Test image upload functionality
4. Verify real-time updates

## Troubleshooting

### Common Issues

1. **CORS Errors**
   - Ensure backend CORS is properly configured
   - Check frontend URL in CORS origin

2. **Authentication Failures**
   - Verify JWT token is being sent
   - Check token expiration
   - Ensure proper Authorization header format

3. **Image Upload Issues**
   - Verify Cloudinary credentials
   - Check image size limits
   - Ensure proper base64 format

4. **Real-time Not Working**
   - Check WebSocket connection
   - Verify Socket.IO client configuration
   - Check for network issues

### Debug Mode

Enable detailed logging in the backend:
```javascript
// In backend/app.js
app.use(morgan('dev')); // HTTP request logging
```

## Performance Considerations

### Backend Optimizations
- Database indexing on frequently queried fields
- Image compression before Cloudinary upload
- Pagination for large message lists
- Caching for user data

### Frontend Optimizations
- React Query for efficient data fetching
- Optimistic updates for better UX
- Image compression before upload
- Debounced search inputs

## Deployment

### Backend Deployment
1. Set production environment variables
2. Configure CORS for production domain
3. Set up SSL certificates
4. Configure database connection

### Frontend Deployment
1. Update API base URL for production
2. Build the application
3. Deploy to hosting service
4. Configure custom domain if needed

## Monitoring

### Backend Monitoring
- Request/response logging
- Error tracking
- Performance metrics
- Database query monitoring

### Frontend Monitoring
- Error boundary implementation
- User interaction tracking
- Performance monitoring
- Real-time error reporting 